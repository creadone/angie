# frozen_string_literal: true

module Angie
  VERSION = "0.1.1"
end
